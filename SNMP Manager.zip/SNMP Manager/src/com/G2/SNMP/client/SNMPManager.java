package com.G2.SNMP.client;
	
	import java.io.IOException;
	
	import org.snmp4j.CommunityTarget;
	import org.snmp4j.PDU;
	import org.snmp4j.Snmp;
	import org.snmp4j.Target;
	import org.snmp4j.TransportMapping;
	import org.snmp4j.event.ResponseEvent;
	import org.snmp4j.mp.SnmpConstants;
	import org.snmp4j.smi.Address;
	import org.snmp4j.smi.GenericAddress;
	import org.snmp4j.smi.OID;
	import org.snmp4j.smi.OctetString;
	import org.snmp4j.smi.VariableBinding;
	import org.snmp4j.transport.DefaultUdpTransportMapping;
	 
	public class SNMPManager {
	 
	Snmp snmp = null;
	String address = null;
	 
	/**
	* Constructor
	* @param add
	*/
	public SNMPManager(String add)
	{
	address = add;
	}
	 
	public static void main(String[] args) throws IOException {
	/**
	* Port 161 is used for Read and Other operations
	* Port 162 is used for the trap generation
	*/
	SNMPManager client = new SNMPManager("udp:10.184.26.162/161");
	client.start();
	/**
	* OID - .1.3.6.1.2.1.1.1.0 => SysDec
	* OID - .1.3.6.1.2.1.1.5.0 => SysName
	* => MIB explorer will be usefull here, as discussed in previous article
	*/
	String sysDescr1 = client.getAsString(new OID("1.3.6.1.4.1.2606.100.1.2.2.1.7.1.1"));
	String sysDescr2 = client.getAsString(new OID("1.3.6.1.4.1.2606.100.1.2.2.1.7.1.2"));
	String sysDescr3 = client.getAsString(new OID("1.3.6.1.4.1.2606.100.1.2.2.1.7.1.3"));
	String sysDescr4 = client.getAsString(new OID("1.3.6.1.4.1.2606.100.1.2.2.1.12.1.1"));
	String sysDescr5 = client.getAsString(new OID("1.3.6.1.4.1.2606.100.1.2.2.1.12.1.2"));
	String sysDescr6 = client.getAsString(new OID("1.3.6.1.4.1.2606.100.1.2.2.1.12.1.3"));
	
	double currentBefore1=Double.parseDouble(sysDescr1);
	double currentAfter1=currentBefore1/100;
	
	double currentBefore2=Double.parseDouble(sysDescr2);
	double currentAfter2=currentBefore2/100;
	
	double currentBefore3=Double.parseDouble(sysDescr3);
	double currentAfter3=currentBefore3/100;
	
	System.out.println("Values of PDU '10.184.26.162':");
	System.out.println("Current L1: " + currentAfter1+ " [A]");
	System.out.println("Current L2: " + currentAfter2 + " [A]");
	System.out.println("Current L3: " + currentAfter3 + " [A]");
	System.out.println();
	System.out.println("Power L1: " + sysDescr4 + " [W]");
	System.out.println("Power L2: " + sysDescr5 + " [W]");
	System.out.println("Power L3: " + sysDescr6 + " [W]");
	
	
	}
	 
	/**
	* Start the Snmp session. If you forget the listen() method you will not
	* get any answers because the communication is asynchronous
	* and the listen() method listens for answers.
	* @throws IOException
	*/
	
	private void start() throws IOException {
	TransportMapping transport = new DefaultUdpTransportMapping();
	snmp = new Snmp(transport);
	// Do not forget this line!
	transport.listen();
	}
	 
	/**

	* Method which takes a single OID and returns the response from the agent as a String.
	* @param oid
	* @return
	* @throws IOException
	*/
	
	public String getAsString(OID oid) throws IOException {
	ResponseEvent event = get(new OID[] { oid });
	return event.getResponse().get(0).getVariable().toString();
	}



	public ResponseEvent get(OID oids[]) throws IOException {
		PDU pdu = new PDU();
		for (OID oid : oids) {
		pdu.add(new VariableBinding(oid));
		}
		pdu.setType(PDU.GET);
		ResponseEvent event = snmp.send(pdu, getTarget(), null);
		if(event != null) {
		return event;
		}
		throw new RuntimeException("GET timed out");
		}
		 
		/**
		* This method returns a Target, which contains information about
		* where the data should be fetched and how.
		* @return
		*/
	
	
		private Target getTarget() {
		Address targetAddress = GenericAddress.parse(address);
		CommunityTarget target = new CommunityTarget();
		target.setCommunity(new OctetString("public"));
		target.setAddress(targetAddress);
		target.setRetries(2);
		target.setTimeout(1500);
		target.setVersion(SnmpConstants.version2c);
		return target;
		}
		 
		}

